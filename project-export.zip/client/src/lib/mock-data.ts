import { 
  Building2, 
  Users, 
  Wrench, 
  DollarSign, 
  AlertCircle, 
  CheckCircle2,
  Clock
} from "lucide-react";

export interface Portfolio {
  id: string;
  name: string;
  code: string;
  status: "Active" | "Inactive";
}

export interface Property {
  id: string;
  portfolioId: string;
  name: string;
  address: string;
  image: string;
  type: "Residential" | "Commercial" | "Mixed";
  units: number;
  occupancyRate: number;
}

export interface Unit {
  id: string;
  propertyId: string;
  unitNumber: string;
  status: "Occupied" | "Vacant" | "Maintenance";
  bedrooms: number;
  bathrooms: number;
  rent: number;
  size: number; // sqft
}

export interface Tenant {
  id: string;
  name: string;
  email: string;
  phone: string;
  status: "Active" | "Past" | "Lead";
  avatar: string;
}

export interface Lease {
  id: string;
  unitId: string;
  tenantId: string;
  startDate: string;
  endDate: string;
  rentAmount: number;
  status: "Active" | "Expiring Soon" | "Expired";
  documents: string[];
}

export interface MaintenanceRequest {
  id: string;
  propertyId: string;
  unitId?: string;
  task_type: "Maintenance Request" | "Property Inspection" | "Move-In Preparation" | "Move-Out Inspection" | "Lease Renewal Process" | "Custom Task";
  category?: string;
  title: string;
  description: string;
  priority: "Low" | "Medium" | "High" | "Critical";
  status: "Open" | "In Progress" | "Completed";
  dateReported: string;
  assignedTo?: string;
  contactName?: string;
  contactPhone?: string;
  comments?: { id: string; text: string; author: string; date: string }[];
  photos?: { url: string; caption: string }[];
  timeline?: { date: string; action: string; author: string; details?: string }[];
}

export interface FinancialRecord {
  id: string;
  propertyId: string;
  unitId?: string;
  type: "Income" | "Expense";
  category: string;
  amount: number;
  date: string;
  description: string;
}

// Mock Data
export const portfolios: Portfolio[] = [
  { id: "port-1", name: "West Coast Holdings", code: "WCH", status: "Active" },
  { id: "port-2", name: "Eastern Ventures", code: "EST", status: "Active" },
];

export const properties: Property[] = [
  {
    id: "prop-1",
    portfolioId: "port-1",
    name: "Sunset Heights Apartments",
    address: "123 Sunset Blvd, Los Angeles, CA",
    image: "/src/assets/images/property-1.jpg",
    type: "Residential",
    units: 24,
    occupancyRate: 92,
  },
  {
    id: "prop-2",
    portfolioId: "port-1",
    name: "Oakwood Business Park",
    address: "450 Oakwood Dr, Pasadena, CA",
    image: "/src/assets/images/property-2.jpg",
    type: "Commercial",
    units: 12,
    occupancyRate: 85,
  },
  {
    id: "prop-3",
    portfolioId: "port-2",
    name: "The Highland Lofts",
    address: "789 Highland Ave, Seattle, WA",
    image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    type: "Residential",
    units: 45,
    occupancyRate: 98,
  }
];

export const units: Unit[] = [
  { id: "u-101", propertyId: "prop-1", unitNumber: "101", status: "Occupied", bedrooms: 2, bathrooms: 1, rent: 2200, size: 950 },
  { id: "u-102", propertyId: "prop-1", unitNumber: "102", status: "Vacant", bedrooms: 2, bathrooms: 1, rent: 2200, size: 950 },
  { id: "u-103", propertyId: "prop-1", unitNumber: "103", status: "Occupied", bedrooms: 1, bathrooms: 1, rent: 1800, size: 750 },
  { id: "u-201", propertyId: "prop-2", unitNumber: "Suite A", status: "Occupied", bedrooms: 0, bathrooms: 2, rent: 4500, size: 2000 },
  { id: "u-202", propertyId: "prop-2", unitNumber: "Suite B", status: "Maintenance", bedrooms: 0, bathrooms: 1, rent: 3200, size: 1500 },
];

export const tenants: Tenant[] = [
  { id: "t-1", name: "Sarah Jenkins", email: "sarah.j@example.com", phone: "(555) 123-4567", status: "Active", avatar: "SJ" },
  { id: "t-2", name: "Michael Chen", email: "m.chen@example.com", phone: "(555) 987-6543", status: "Active", avatar: "MC" },
  { id: "t-3", name: "TechStart Inc.", email: "contact@techstart.io", phone: "(555) 456-7890", status: "Active", avatar: "TS" },
];

export const leases: Lease[] = [
  { id: "l-1", unitId: "u-101", tenantId: "t-1", startDate: "2023-01-01", endDate: "2024-01-01", rentAmount: 2200, status: "Active", documents: ["lease_signed.pdf"] },
  { id: "l-2", unitId: "u-201", tenantId: "t-3", startDate: "2022-06-01", endDate: "2025-06-01", rentAmount: 4500, status: "Active", documents: ["commercial_lease.pdf"] },
];

export const maintenanceRequests: MaintenanceRequest[] = [
  { 
    id: "m-1", 
    propertyId: "prop-1", 
    unitId: "u-103", 
    task_type: "Maintenance Request",
    category: "Plumbing",
    title: "Leaking Faucet", 
    description: "Kitchen sink faucet is dripping constantly.", 
    priority: "Low", 
    status: "Open", 
    dateReported: "2023-10-15", 
    assignedTo: "Mario",
    contactName: "John Doe",
    contactPhone: "(555) 123-4567",
    comments: [
      { id: "c-1", text: "Tenant reported issue via phone.", author: "Admin", date: "2023-10-15" }
    ],
    timeline: [
      { date: "2023-10-15", action: "Created", author: "Admin", details: "Initial report" }
    ]
  },
  { 
    id: "m-2", 
    propertyId: "prop-2", 
    unitId: "u-202", 
    task_type: "Maintenance Request",
    category: "HVAC",
    title: "HVAC Malfunction", 
    description: "AC unit making loud banging noises.", 
    priority: "High", 
    status: "In Progress", 
    dateReported: "2023-10-14", 
    assignedTo: "TechCool Services",
    contactName: "Jane Smith",
    contactPhone: "(555) 987-6543",
    comments: [],
    timeline: [
      { date: "2023-10-14", action: "Created", author: "System" },
      { date: "2023-10-15", action: "Assigned", author: "Admin", details: "Assigned to TechCool Services" }
    ]
  },
  { 
    id: "m-3", 
    propertyId: "prop-1", 
    task_type: "Property Inspection",
    category: "General",
    title: "Lobby Light Out", 
    description: "Main entrance overhead light is flickering.", 
    priority: "Medium", 
    status: "Completed", 
    dateReported: "2023-10-10",
    timeline: [
      { date: "2023-10-10", action: "Created", author: "Security" },
      { date: "2023-10-12", action: "Completed", author: "Mario", details: "Replaced bulb" }
    ]
  },
  {
    id: "m-4",
    propertyId: "prop-1",
    unitId: "u-102",
    task_type: "Move-In Preparation",
    category: "Turnover",
    title: "Unit 102 Prep",
    description: "Clean and paint unit for new tenant arrival.",
    priority: "High",
    status: "Open",
    dateReported: "2023-10-20",
    assignedTo: "Cleaning Crew A",
    timeline: [
      { date: "2023-10-20", action: "Created", author: "Leasing Agent" }
    ]
  },
  {
    id: "m-5",
    propertyId: "prop-2",
    unitId: "u-201",
    task_type: "Lease Renewal Process",
    category: "Administrative",
    title: "Suite A Renewal",
    description: "Prepare renewal documents for TechStart Inc.",
    priority: "Medium",
    status: "In Progress",
    dateReported: "2023-10-18",
    assignedTo: "Leasing Office",
    timeline: [
      { date: "2023-10-18", action: "Created", author: "System" }
    ]
  }
];

export interface Account {
  id: string;
  code: string;
  name: string;
  type: "Asset" | "Liability" | "Equity" | "Revenue" | "Expense";
  category: string;
  balance: number;
}

export interface JournalEntry {
  id: string;
  date: string;
  description: string;
  reference?: string; // Invoice ID, Lease ID, etc.
  status: "Draft" | "Posted";
  lines: {
    accountId: string;
    description: string;
    debit: number;
    credit: number;
  }[];
}

export const chartOfAccounts: Account[] = [
  { id: "acc-1001", code: "1001", name: "Operating Cash", type: "Asset", category: "Cash", balance: 125000 },
  { id: "acc-1100", code: "1100", name: "Accounts Receivable", type: "Asset", category: "Receivables", balance: 45000 },
  { id: "acc-2000", code: "2000", name: "Accounts Payable", type: "Liability", category: "Payables", balance: 12000 },
  { id: "acc-2100", code: "2100", name: "Security Deposits", type: "Liability", category: "Deposits", balance: 35000 },
  { id: "acc-4000", code: "4000", name: "Rental Income", type: "Revenue", category: "Income", balance: 240000 },
  { id: "acc-5000", code: "5000", name: "Repairs & Maintenance", type: "Expense", category: "Operations", balance: 15000 },
  { id: "acc-5100", code: "5100", name: "Utilities", type: "Expense", category: "Operations", balance: 8000 },
];

export const financialStats = [
  { name: "Jan", income: 45000, expenses: 12000 },
  { name: "Feb", income: 42000, expenses: 15000 },
  { name: "Mar", income: 48000, expenses: 11000 },
  { name: "Apr", income: 46000, expenses: 18000 },
  { name: "May", income: 51000, expenses: 10000 },
  { name: "Jun", income: 49000, expenses: 13000 },
];

export const journalEntries: JournalEntry[] = [
  {
    id: "je-1",
    date: "2023-10-01",
    description: "Monthly Rent Recognition - Unit 101",
    reference: "l-1",
    status: "Posted",
    lines: [
      { accountId: "acc-1100", description: "Rent receivable", debit: 2200, credit: 0 },
      { accountId: "acc-4000", description: "Rent income", debit: 0, credit: 2200 },
    ]
  },
  {
    id: "je-2",
    date: "2023-10-05",
    description: "HVAC Repair - Split Entry",
    reference: "m-2",
    status: "Posted",
    lines: [
      { accountId: "acc-5000", description: "Labor portion", debit: 500, credit: 0 },
      { accountId: "acc-5100", description: "Parts portion", debit: 300, credit: 0 },
      { accountId: "acc-2000", description: "Payable to TechCool", debit: 0, credit: 800 },
    ]
  }
];

export interface Party {
  id: string;
  name: string;
  type: "Vendor" | "Customer" | "Tenant" | "Employee" | "Other";
  email: string;
  phone: string;
  status: "Active" | "Inactive";
  balance: number;
}

export const parties: Party[] = [
  { id: "p-1", name: "TechCool Services", type: "Vendor", email: "support@techcool.com", phone: "(555) 123-4567", status: "Active", balance: -800 },
  { id: "p-2", name: "City Utilities", type: "Vendor", email: "billing@city.gov", phone: "(555) 987-6543", status: "Active", balance: -150 },
  { id: "p-3", name: "Sarah Jenkins", type: "Tenant", email: "sarah.j@example.com", phone: "(555) 555-0123", status: "Active", balance: 0 },
  { id: "p-4", name: "Ace Plumbing", type: "Vendor", email: "contact@aceplumbing.com", phone: "(555) 555-0199", status: "Inactive", balance: 0 },
];
